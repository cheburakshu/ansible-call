import os
import sys

CODE_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), "src"))
sys.path.insert(0, CODE_DIR)
