def test_hatch():
    a = "hello"
    assert a == "hello"
