# ansible-call
A minimal library to call ansible modules with a python script
